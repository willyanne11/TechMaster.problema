package com.isabelle.gestaoproblema;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; 
import java.util.ArrayList;
import java.util.List;
import com.isabelle.gestaoproblema.DatabaseManager;

// A classe SubAcaoCorretiva agora lida com a persistência (Padrão Active Record)
public class SubAcaoCorretiva { // Classe renomeada
    
    // ATRIBUTOS (FIELDS) - Mapeamento das colunas da tabela SUBACOES_CORRETIVAS
    private int id; 
    private int acaoCorretivaId; // Renomeado de planoId
    private String descricao; 
    private String responsavel; 
    private String prazoConclusao; 
    private String dataConclusao; 
    private String progresso; 
    private String observacoes; 

    // CONSTRUTOR P/ NOVO OBJETO
    public SubAcaoCorretiva(int acaoCorretivaId, String descricao, String responsavel, String prazoConclusao) {
        this.acaoCorretivaId = acaoCorretivaId; // Variável alterada
        this.descricao = descricao;
        this.responsavel = responsavel;
        this.prazoConclusao = prazoConclusao;
        this.progresso = "Pendente"; 
    }

    // CONSTRUTOR P/ CARREGAR DO BANCO (Completo)
    public SubAcaoCorretiva(int id, int acaoCorretivaId, String descricao, String responsavel, String prazoConclusao, String progresso) {
        this.id = id;
        this.acaoCorretivaId = acaoCorretivaId; // Variável alterada
        this.descricao = descricao;
        this.responsavel = responsavel;
        this.prazoConclusao = prazoConclusao;
        this.progresso = progresso;
    }

    // --- FUNCIONALIDADE DE PERSISTÊNCIA (CREATE) ---
    public void salvar() {
        // Tabela alterada para SUBACOES_CORRETIVAS e coluna para ACAO_CORRETIVA_ID
        String sql = "INSERT INTO SUBACOES_CORRETIVAS (ACAO_CORRETIVA_ID, DESCRICAO, RESPONSAVEL, PRAZO_CONCLUSAO, PROGRESSO) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, this.acaoCorretivaId); // Variável alterada
            stmt.setString(2, this.descricao);
            stmt.setString(3, this.responsavel);
            stmt.setString(4, this.prazoConclusao);
            stmt.setString(5, this.progresso);

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        this.id = rs.getInt(1); 
                    }
                }
            }
        } catch (SQLException e) { 
            System.err.println("Erro ao salvar a Sub-Ação Corretiva: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // --- FUNCIONALIDADE DE BUSCA (READ) ---
    public static List<SubAcaoCorretiva> buscarPorAcaoCorretiva(int acaoCorretivaId) { // Método renomeado
        List<SubAcaoCorretiva> acoes = new ArrayList<>();
        // Tabela alterada para SUBACOES_CORRETIVAS e coluna para ACAO_CORRETIVA_ID
        String sql = "SELECT * FROM SUBACOES_CORRETIVAS WHERE ACAO_CORRETIVA_ID = ?"; 
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, acaoCorretivaId); 
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    SubAcaoCorretiva acao = new SubAcaoCorretiva(
                        rs.getInt("ID"),
                        rs.getInt("ACAO_CORRETIVA_ID"), // Coluna alterada
                        rs.getString("DESCRICAO"),
                        rs.getString("RESPONSAVEL"),
                        rs.getString("PRAZO_CONCLUSAO"),
                        rs.getString("PROGRESSO")
                    );
                    acoes.add(acao);
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar sub-ações por ação corretiva: " + e.getMessage());
            e.printStackTrace();
        }
        return acoes;
    }
    
    // Getters
    public int getId() {
        return id;
    }
    public int getAcaoCorretivaId() { // Renomeado
        return acaoCorretivaId;
    }
    // ... outros getters e setters (não mostrados para brevidade)
}