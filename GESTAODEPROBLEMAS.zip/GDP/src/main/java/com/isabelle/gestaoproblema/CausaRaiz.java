package com.isabelle.gestaoproblema;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet; 
import com.isabelle.gestaoproblema.DatabaseManager; 

// Esta classe agora é responsável tanto pelos dados quanto pela sua persistência (Padrão Active Record)
public class CausaRaiz { // Classe renomeada

    // ---------- ATRIBUTOS ----------
    private int id;                  
    private int problemaId;            // Renomeado de riscoId
    private int impacto;              
    private int probabilidade;        
    private int urgencia;             
    private int pontuacaoGeral;       
    private String dataInvestigacao;    // Renomeado de dataAvaliacao
    private String responsavel;       
    private  String justificativa;     

    // ---------- CONSTRUTOR P/ NOVAS CAUSAS RAIZ ----------
    public CausaRaiz(int problemaId, int impacto, int probabilidade, int urgencia, int pontuacaoGeral, String dataInvestigacao, String responsavel, String justificativa) {
        this.problemaId = problemaId;
        this.impacto = impacto;
        this.probabilidade = probabilidade;
        this.urgencia = urgencia;
        this.pontuacaoGeral = pontuacaoGeral;
        this.dataInvestigacao = dataInvestigacao;
        this.responsavel = responsavel;
        this.justificativa = justificativa;
    }

    // ---------- CONSTRUTOR P/ CARREGAR DO BANCO ----------
    public CausaRaiz(int id, int problemaId, int impacto, int probabilidade, int urgencia, int pontuacaoGeral, String dataInvestigacao, String responsavel, String justificativa) {
        this(problemaId, impacto, probabilidade, urgencia, pontuacaoGeral, dataInvestigacao, responsavel, justificativa);
        this.id = id;
    }

    // ---------- MÉTODO DE PERSISTÊNCIA (CREATE) ----------
    public void salvar() {
        // Tabela alterada para CAUSA_RAIZ e coluna para PROBLEMA_ID
        String sql = "INSERT INTO CAUSA_RAIZ (PROBLEMA_ID, IMPACTO, PROBABILIDADE, URGENCIA, PONTUACAO_GERAL, DATA_INVESTIGACAO, RESPONSAVEL, JUSTIFICATIVA) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) { 

            stmt.setInt(1, this.problemaId); // Variável alterada
            stmt.setInt(2, this.impacto);        
            stmt.setInt(3, this.probabilidade);  
            stmt.setInt(4, this.urgencia);       
            stmt.setInt(5, this.pontuacaoGeral); 
            stmt.setString(6, this.dataInvestigacao); // Variável alterada
            stmt.setString(7, this.responsavel);   
            stmt.setString(8, this.justificativa); 

            int affectedRows = stmt.executeUpdate(); 

            if (affectedRows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        this.setId(rs.getInt(1));
                    }
                }
            }
        } catch (SQLException e) { 
            System.err.println("Erro ao salvar Causa Raiz: " + e.getMessage());
            e.printStackTrace();   
        }
    }
    
    // ---------- FUNCIONALIDADE DE BUSCA (READ) ----------
    public static CausaRaiz buscarPorProblemaId(int problemaId) { // Método renomeado
        CausaRaiz causaRaiz = null;
        String sql = "SELECT * FROM CAUSA_RAIZ WHERE PROBLEMA_ID = ?"; // Tabela e coluna alteradas

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, problemaId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    causaRaiz = new CausaRaiz(
                        rs.getInt("ID"),
                        rs.getInt("PROBLEMA_ID"), // Coluna alterada
                        rs.getInt("IMPACTO"),
                        rs.getInt("PROBABILIDADE"),
                        rs.getInt("URGENCIA"),
                        rs.getInt("PONTUACAO_GERAL"),
                        rs.getString("DATA_INVESTIGACAO"), // Coluna alterada
                        rs.getString("RESPONSAVEL"),
                        rs.getString("JUSTIFICATIVA")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar Causa Raiz por ID do Problema: " + e.getMessage());
            e.printStackTrace();
        }
        return causaRaiz;
    }
    
    // ---------- GETTERS e SETTERS ----------
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getProblemaId() { // Renomeado
        return problemaId;
    }
    // ... outros getters e setters (não mostrados para brevidade)
}