package com.isabelle.gestaoproblema;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

// A classe AcaoCorretiva agora armazena os dados E lida com a persistência (Padrão Active Record)
public class AcaoCorretiva { // Classe renomeada
    
    // Atributos privados - Mapeamento das colunas da tabela ACAO_CORRETIVA
    private int id;                 
    private int problemaId;         // Renomeado de riscoId
    private String descricao;        
    private String dataProposta;     
    private String status;           

    // Construtor completo (Para ler do banco)
    public AcaoCorretiva(int id, int problemaId, String descricao, String dataProposta, String status) {
        this.id = id;
        this.problemaId = problemaId; // Variável alterada
        this.descricao = descricao;
        this.dataProposta = dataProposta;
        this.status = status;
    }

    // Construtor simplificado (Para criar um novo objeto)
    public AcaoCorretiva(int problemaId, String descricao, String dataProposta, String status) {
        this.problemaId = problemaId; // Variável alterada
        this.descricao = descricao;
        this.dataProposta = dataProposta;
        this.status = status;
    }

    // --- FUNCIONALIDADE DE PERSISTÊNCIA (CREATE) ---
    public void salvar() {
        // Tabela alterada para ACAO_CORRETIVA e coluna para PROBLEMA_ID
        String sql = "INSERT INTO ACAO_CORRETIVA (PROBLEMA_ID, DESCRICAO, DATA_PROPOSTA, STATUS) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, this.problemaId); // Variável alterada
            stmt.setString(2, this.descricao);
            stmt.setString(3, this.dataProposta);
            stmt.setString(4, this.status);

            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        this.id = rs.getInt(1); 
                        
                        // Atualiza o status do Problema após a criação da Ação Corretiva
                        Problema.atualizarStatus(this.problemaId, "Com Ação Corretiva");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao salvar a Ação Corretiva: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // --- FUNCIONALIDADE DE BUSCA (READ) ---
    public static List<AcaoCorretiva> buscarPorProblema(int problemaId) { // Método renomeado
        List<AcaoCorretiva> acoes = new ArrayList<>();
        String sql = "SELECT * FROM ACAO_CORRETIVA WHERE PROBLEMA_ID = ?"; // Tabela e coluna alteradas
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, problemaId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    acoes.add(new AcaoCorretiva(
                        rs.getInt("ID"),
                        rs.getInt("PROBLEMA_ID"), // Coluna alterada
                        rs.getString("DESCRICAO"),
                        rs.getString("DATA_PROPOSTA"),
                        rs.getString("STATUS")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar ações por problema: " + e.getMessage());
            e.printStackTrace();
        }
        return acoes;
    }
    
    // Método para a CLI.
    public static void listarTodos() {
        String sql = "SELECT ID, DESCRICAO, STATUS FROM ACAO_CORRETIVA";
        
        try (Connection conn = DatabaseManager.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            System.out.println("--- Ações Corretivas Disponíveis ---");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("ID") + 
                                   " | Descrição: " + rs.getString("DESCRICAO") + 
                                   " | Status: " + rs.getString("STATUS"));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar todas as ações: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Getters
    public int getId() {
        return id;
    }
    public int getProblemaId() { // Renomeado
        return problemaId;
    }
    // ... outros getters e setters (não mostrados para brevidade)
}