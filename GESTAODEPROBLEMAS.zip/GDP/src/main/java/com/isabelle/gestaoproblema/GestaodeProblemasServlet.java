package com.isabelle.gestaoproblema;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * Servlet principal para a aplicação de Gestão de Problemas. Atua como o
 * controlador central, roteando as requisições.
 */
@WebServlet("/gestao")
public class GestaodeProblemasServlet extends HttpServlet {

	@Override
	public void init() throws ServletException {
		super.init();
		DatabaseManager.initializeDatabase();
		System.out.println("Banco de Dados inicializado para o Servlet (Gestão de Problemas).");
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String acao = request.getParameter("acao");

		if (acao == null) {
			acao = "listarProblemas"; // Ação padrão
		}

		try {
			switch (acao) {
			case "novoProblema":
				mostrarFormNovoProblema(request, response);
				break;
			case "listarProblemas":
				listarProblemas(request, response);
				break;
			case "formCausaRaiz":
				mostrarFormCausaRaiz(request, response);
				break;
			case "formAcaoCorretiva":
				mostrarFormAcaoCorretiva(request, response);
				break;
			case "formSubAcao":
				mostrarFormSubAcao(request, response);
				break;
			default:
				listarProblemas(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String acao = request.getParameter("acao");

		try {
			if (acao != null) {
				switch (acao) {
				case "inserirProblema":
					inserirProblema(request, response);
					break;
				case "inserirCausaRaiz":
					inserirCausaRaiz(request, response);
					break;
				case "inserirAcaoCorretiva":
					inserirAcaoCorretiva(request, response);
					break;
				case "inserirSubAcao":
					inserirSubAcao(request, response);
					break;
				default:
					response.sendRedirect("gestao?acao=listarProblemas");
					break;
				}
			} else {
				response.sendRedirect("gestao?acao=listarProblemas");
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	// --- MÉTODOS DE ROTEAMENTO (GET) ---

	private void mostrarFormNovoProblema(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/formNovoProblema.jsp").forward(request, response);
	}

	private void listarProblemas(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Problema> listaProblemas = Problema.listarTodos();
		request.setAttribute("listaProblemas", listaProblemas);
		// ✅ corrigido para o nome certo do JSP existente
		request.getRequestDispatcher("/listarProblemas.jsp").forward(request, response);
	}

	private void mostrarFormCausaRaiz(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// CORRIGIDO: Lê o parâmetro 'problemaId' enviado pelo JSP
			int problemaId = Integer.parseInt(request.getParameter("problemaId"));
			request.setAttribute("problemaId", problemaId);

			// Assume-se que o JSP foi renomeado
			request.getRequestDispatcher("/formCausaRaiz.jsp").forward(request, response);
		} catch (NumberFormatException e) {
			request.setAttribute("erro", "ID do Problema inválido.");
			request.getRequestDispatcher("/listarProblemas.jsp").forward(request, response);
		}
	}

	private void mostrarFormAcaoCorretiva(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			// CORRIGIDO: Lê o parâmetro 'problemaId' enviado pelo JSP
			int problemaId = Integer.parseInt(request.getParameter("problemaId"));
			request.setAttribute("problemaId", problemaId);

			// Assume-se que o JSP foi renomeado
			request.getRequestDispatcher("/formAcaoCorretiva.jsp").forward(request, response);
		} catch (NumberFormatException e) {
			request.setAttribute("erro", "ID do Problema inválido.");
			request.getRequestDispatcher("/listarProblemas.jsp").forward(request, response);
		}
	}

	private void mostrarFormSubAcao(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int acaoCorretivaId = Integer.parseInt(request.getParameter("id"));
			request.setAttribute("acaoCorretivaId", acaoCorretivaId);
			request.getRequestDispatcher("/formSubAcao.jsp").forward(request, response);
		} catch (NumberFormatException e) {
			request.setAttribute("erro", "ID da Ação Corretiva inválido.");
			response.sendRedirect("gestao?acao=listarProblemas");
		}
	}

	// --- MÉTODOS DE AÇÃO (POST) ---

	private void inserirProblema(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			String descricao = request.getParameter("descricao");
			String origem = request.getParameter("origem");
			String dataIdentificacao = request.getParameter("dataIdentificacao");

			// CORRIGIDO: Lê o parâmetro 'tipoProblemaId' enviado pelo JSP
			int tipoProblemaId = Integer.parseInt(request.getParameter("tipoProblemaId"));

			Problema problema = new Problema(descricao, origem, dataIdentificacao, tipoProblemaId);
			problema.salvar();

			response.sendRedirect("app?acao=listarProblemas");
		} catch (NumberFormatException e) {
			request.setAttribute("erro", "ID do Tipo de Problema inválido.");
			request.getRequestDispatcher("/formNovoProblema.jsp").forward(request, response);
		}
	}

	private void inserirCausaRaiz(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int problemaId = Integer.parseInt(request.getParameter("idProblema"));
			int impacto = Integer.parseInt(request.getParameter("impacto"));
			int probabilidade = Integer.parseInt(request.getParameter("probabilidade"));
			int urgencia = Integer.parseInt(request.getParameter("urgencia"));
			String responsavel = request.getParameter("responsavel");
			String justificativa = request.getParameter("justificativa");

			int pontuacaoGeral = impacto * probabilidade * urgencia;
			String dataInvestigacao = LocalDate.now().toString();

			CausaRaiz causaRaiz = new CausaRaiz(problemaId, impacto, probabilidade, urgencia, pontuacaoGeral,
					dataInvestigacao, responsavel, justificativa);
			causaRaiz.salvar();

			Problema.atualizarStatus(problemaId, "Investigado");

			response.sendRedirect("gestao?acao=listarProblemas");
		} catch (NumberFormatException e) {
			request.setAttribute("erro", "Um ou mais campos numéricos são inválidos.");
			request.getRequestDispatcher("/formCausaRaiz.jsp").forward(request, response);
		}
	}

	private void inserirAcaoCorretiva(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int problemaId = Integer.parseInt(request.getParameter("problemaId"));
			String descricao = request.getParameter("descricao");
			String dataProposta = request.getParameter("dataProposta");

			AcaoCorretiva acaoCorretiva = new AcaoCorretiva(problemaId, descricao, dataProposta, "Proposta");
			acaoCorretiva.salvar();

			response.sendRedirect("gestao?acao=listarProblemas");
		} catch (NumberFormatException e) {
			request.setAttribute("erro", "ID do Problema inválido.");
			request.getRequestDispatcher("/formAcaoCorretiva.jsp").forward(request, response);
		}
	}

	private void inserirSubAcao(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			int acaoCorretivaId = Integer.parseInt(request.getParameter("acaoCorretivaId"));
			String descricao = request.getParameter("descricao");
			String responsavel = request.getParameter("responsavel");
			String prazoConclusao = request.getParameter("prazoConclusao");

			SubAcaoCorretiva subAcao = new SubAcaoCorretiva(acaoCorretivaId, descricao, responsavel, prazoConclusao);
			subAcao.salvar();

			response.sendRedirect("gestao?acao=listarProblemas");
		} catch (NumberFormatException e) {
			request.setAttribute("erro", "ID da Ação Corretiva inválido.");
			response.sendRedirect("gestao?acao=listarProblemas");
		}
	}
}
