package com.isabelle.gestaoproblema;

import com.isabelle.gestaoproblema.DatabaseManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe de modelo (Model) para a entidade Problema, utilizando o padrão Active Record
 * para lidar com sua própria persistência (CRUD).
 */
public class Problema {
    // Atributos privados que mapeiam as colunas da tabela PROBLEMA
    private int id;
    private String descricao;
    private String origem;
    private String dataIdentificacao; // Formato yyyy-MM-dd
    private String status;
    private int tipoProblemaId; // Renomeado de tipoRiscoId

    // Construtor usado para criar um novo Problema (o ID será gerado pelo BD)
    public Problema(String descricao, String origem, String dataIdentificacao, int tipoProblemaId) {
        this.descricao = descricao;
        this.origem = origem;
        this.dataIdentificacao = dataIdentificacao;
        this.status = "Identificado"; // Status inicial padrão para todo novo problema
        this.tipoProblemaId = tipoProblemaId;
    }

    // Construtor usado para carregar um Problema existente do BD
    public Problema(int id, String descricao, String origem, String dataIdentificacao, String status, int tipoProblemaId) {
        this.id = id;
        this.descricao = descricao;
        this.origem = origem;
        this.dataIdentificacao = dataIdentificacao;
        this.status = status;
        this.tipoProblemaId = tipoProblemaId;
    }

    // --- FUNCIONALIDADE DE PERSISTÊNCIA (CREATE) ---
    /**
     * Salva este objeto Problema no banco de dados.
     */
    public void salvar() {
        // A instrução SQL deve incluir todas as colunas que o construtor preenche.
        String sql = "INSERT INTO PROBLEMA (DESCRICAO, ORIGEM, DATA_IDENTIFICACAO, STATUS, TIPO_PROBLEMA_ID) VALUES (?, ?, ?, ?, ?)";

        // O bloco try-with-resources garante que a conexão e o statement sejam fechados.
        try (Connection conn = DatabaseManager.getConnection(); // Obtém a conexão
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            // 1. Mapeamento dos parâmetros do objeto para a instrução SQL
            stmt.setString(1, this.descricao);
            stmt.setString(2, this.origem);
            stmt.setString(3, this.dataIdentificacao);
            stmt.setString(4, this.status); // Status inicial: "Identificado"
            stmt.setInt(5, this.tipoProblemaId);

            // 2. EXECUTAR A INSERÇÃO (Parte mais crítica!)
            int linhasAfetadas = stmt.executeUpdate(); 

            if (linhasAfetadas > 0) {
                // Opcional: Recuperar o ID gerado pelo banco para o objeto
                try (ResultSet rs = stmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        this.id = rs.getInt(1);
                        System.out.println("Problema salvo com sucesso! ID gerado: " + this.id);
                    }
                }
            }
        } catch (SQLException e) {
            // Se houver erro, ele será impresso no console do servidor (Tomcat)
            System.err.println("Erro ao salvar o problema no banco de dados: " + e.getMessage());
            e.printStackTrace();
        }
    }
    // --- FUNCIONALIDADE DE BUSCA (READ) ---
    public static List<Problema> listarTodos() {
        List<Problema> problemas = new ArrayList<>();
        String sql = "SELECT * FROM PROBLEMA";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Problema problema = new Problema(
                    rs.getInt("ID"),
                    rs.getString("DESCRICAO"),
                    rs.getString("ORIGEM"),
                    rs.getString("DATA_IDENTIFICACAO"),
                    rs.getString("STATUS"),
                    rs.getInt("TIPO_PROBLEMA_ID") // Coluna alterada
                );
                problemas.add(problema);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar Problemas: " + e.getMessage());
            e.printStackTrace();
        }
        return problemas;
    }
    
    public static Problema buscarPorId(int id) {
        Problema problema = null;
        String sql = "SELECT * FROM PROBLEMA WHERE ID = ?";

        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    problema = new Problema(
                        rs.getInt("ID"),
                        rs.getString("DESCRICAO"),
                        rs.getString("ORIGEM"),
                        rs.getString("DATA_IDENTIFICACAO"),
                        rs.getString("STATUS"),
                        rs.getInt("TIPO_PROBLEMA_ID") // Coluna alterada
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar Problema por ID: " + e.getMessage());
            e.printStackTrace();
        }
        return problema;
    }
    
    // --- FUNCIONALIDADE DE ATUALIZAÇÃO (UPDATE) ---
    public static void atualizarStatus(int id, String novoStatus) {
        String sql = "UPDATE PROBLEMA SET STATUS = ? WHERE ID = ?";
        
        try (Connection conn = DatabaseManager.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, novoStatus);
            stmt.setInt(2, id);

            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar status do Problema: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return String.format("[ID: %d] %s (Origem: %s) | Status: %s | Tipo ID: %d",
                             id, descricao, origem, status, tipoProblemaId);
    }

    // Getters para a nova classe CausaRaiz, AcaoCorretiva e SubAcaoCorretiva
 // No final do arquivo Problema.java, após o método toString()

    // --- GETTERS E SETTERS ---
    
    // Getters obrigatórios para o JSP listarProblemas.jsp:
    
    public String getDescricao() {
        return descricao;
    }

    public String getOrigem() {
        return origem;
    }

    public String getDataIdentificacao() {
        return dataIdentificacao;
    }

    public String getStatus() {
        return status;
    }
    
    // Getters existentes:
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getTipoProblemaId() {
        return tipoProblemaId;
    }
    
    // Setters (opcionais, mas boas práticas):
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    // ... adicione outros setters se necessário ...

}
    // ... outros getters e setters (não mostrados para brevidade)
