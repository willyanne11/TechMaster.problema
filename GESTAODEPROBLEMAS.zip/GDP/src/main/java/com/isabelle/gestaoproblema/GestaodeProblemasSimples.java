package com.isabelle.gestaoproblema;


import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.List; 
import java.time.LocalDate;

// A classe `GestaodeProblemasSimples` atua como a interface de linha de comando (CLI)
// para o sistema de gestão de problemas, utilizando o Padrão Active Record.
public class GestaodeProblemasSimples { // Classe renomeada

    private static Scanner n = new Scanner(System.in);

    public static void main(String[] args) {
        // Inicializa o banco de dados.
        DatabaseManager.initializeDatabase();
        
        try {
            int opcao;
            do {
                exibirMenu();
                try {
                    opcao = n.nextInt();
                    n.nextLine();

                    switch (opcao) {
                        case 1:
                            registrarProblema(); // Método renomeado
                            break;
                        case 2:
                            visualizarProblemas(); // Método renomeado
                            break;
                        case 3:
                            registrarCausaRaiz(); // Método renomeado
                            break;
                        case 4:
                            registrarAcaoCorretiva(); // Método renomeado
                            break;
                        case 5:
                            registrarSubAcaoCorretiva(); // Método renomeado
                            break;
                        case 0:
                            System.out.println("Saindo do sistema. Adeus!");
                            break;
                        default:
                            System.out.println("Opção inválida. Tente novamente.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Entrada inválida. Por favor, digite um número.");
                    n.nextLine(); 
                    opcao = -1; 
                }

            } while (opcao != 0);
        } finally {
            n.close();
        }
    }

    private static void exibirMenu() {
        System.out.println("\n--- Sistema de Gestão de Problemas ---");
        System.out.println("1. Registrar Novo Problema");
        System.out.println("2. Visualizar Problemas Registrados");
        System.out.println("3. Registrar Causa Raiz (Investigar Problema)");
        System.out.println("4. Registrar Ação Corretiva (Proposta)");
        System.out.println("5. Registrar Sub-Ação Corretiva (Detalhe da Ação)");
        System.out.println("0. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private static void registrarProblema() {
        System.out.println("\n--- Registrar Novo Problema ---");
        System.out.print("Descrição do Problema: ");
        String descricao = n.nextLine();
        System.out.print("Origem do Problema: ");
        String origem = n.nextLine();
        System.out.print("Data de Identificação (yyyy-MM-dd): ");
        String dataIdentificacao = n.nextLine();
        System.out.print("ID do Tipo de Problema (ID do Tipo de Risco): ");
        int tipoProblemaId; // Variável renomeada
        try {
            tipoProblemaId = n.nextInt();
            n.nextLine(); 
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida para o Tipo de Problema. Usando 1 como padrão.");
            n.nextLine();
            tipoProblemaId = 1;
        }

        // Usa a nova classe Problema
        Problema problema = new Problema(descricao, origem, dataIdentificacao, tipoProblemaId);
        problema.salvar();
        System.out.println("Problema registrado com sucesso! ID: " + problema.getId());
    }

    private static void visualizarProblemas() {
        System.out.println("\n--- Problemas Registrados ---");
        List<Problema> problemas = Problema.listarTodos();
        if (problemas.isEmpty()) {
            System.out.println("Nenhum problema registrado.");
        } else {
            for (Problema p : problemas) {
                System.out.println(p.toString());
            }
        }
    }

    private static void registrarCausaRaiz() {
        visualizarProblemas();
        System.out.print("\nDigite o ID do Problema para registrar a Causa Raiz: ");
        try {
            int idProblema = n.nextInt(); // Variável renomeada
            n.nextLine(); 

            System.out.print("Impacto (1-5): ");
            int impacto = n.nextInt();
            System.out.print("Probabilidade (1-5): ");
            int probabilidade = n.nextInt();
            System.out.print("Urgência (1-5): ");
            int urgencia = n.nextInt();
            n.nextLine();
            
            System.out.print("Responsável pela Investigação: ");
            String responsavel = n.nextLine();
            System.out.print("Justificativa da Causa Raiz: ");
            String justificativa = n.nextLine();

            int pontuacaoGeral = impacto * probabilidade * urgencia;
            String dataInvestigacao = LocalDate.now().toString();

            // Usa a nova classe CausaRaiz
            CausaRaiz causaRaiz = new CausaRaiz(idProblema, impacto, probabilidade, urgencia,
                    pontuacaoGeral, dataInvestigacao, responsavel, justificativa);
            causaRaiz.salvar();

            Problema.atualizarStatus(idProblema, "Investigado");

            System.out.println("Causa Raiz registrada com sucesso!");
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            n.nextLine();
        }
    }
    
    private static void registrarAcaoCorretiva() {
        visualizarProblemas();
        System.out.print("\nDigite o ID do Problema para criar a Ação Corretiva: ");
        try {
            int idProblema = n.nextInt(); // Variável renomeada
            n.nextLine();

            System.out.print("Descrição da Ação Corretiva: ");
            String descricao = n.nextLine();
            String dataProposta = LocalDate.now().toString(); 

            // Usa a nova classe AcaoCorretiva
            AcaoCorretiva acao = new AcaoCorretiva(idProblema, descricao, dataProposta, "Proposta");
            acao.salvar();

            System.out.println("Ação Corretiva registrada com sucesso!");
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            n.nextLine();
        }
    }
    
    private static void registrarSubAcaoCorretiva() {
        // Usa a nova classe AcaoCorretiva
        AcaoCorretiva.listarTodos(); 

        System.out.print("Digite o ID da Ação Corretiva (Plano) para adicionar a Sub-Ação: ");
        try {
            int idAcaoCorretiva = n.nextInt(); // Variável renomeada
            n.nextLine();

            System.out.print("Descrição da Sub-Ação: ");
            String descricao = n.nextLine();
            System.out.print("Responsável: ");
            String responsavel = n.nextLine();
            System.out.print("Prazo de Conclusão (yyyy-MM-dd): ");
            String prazoConclusao = n.nextLine();

            // Usa a nova classe SubAcaoCorretiva
            SubAcaoCorretiva subAcao = new SubAcaoCorretiva(idAcaoCorretiva, descricao, responsavel, prazoConclusao);
            subAcao.salvar();
            
            System.out.println("Sub-Ação Corretiva registrada com sucesso!");
        } catch (InputMismatchException e) {
            System.out.println("Entrada inválida. Por favor, digite um número.");
            n.nextLine();
        }
    }
}