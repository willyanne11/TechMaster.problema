package com.isabelle.gestaoproblema;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 * Classe utilitária para gerenciar a conexão com o banco de dados H2.
 * Responsável por obter a conexão e inicializar a estrutura do banco de dados (schema)
 * para o módulo de Gestão de Problemas.
 */
public class DatabaseManager {

    // ***************************************************************
    // 1. CONSTANTES DE CONEXÃO
    // ***************************************************************
    // URL alterada para refletir o novo domínio (gestaodeproblemas_db)
    private static final String JDBC_URL = "jdbc:h2:C:/DadosCompartilhados/gestaodeproblemas_db";
    private static final String USER = "sa"; 
    private static final String PASSWORD = ""; 

    /**
     * Obtém uma conexão com o banco de dados.
     * @return uma conexão válida com o banco de dados.
     * @throws SQLException se a conexão falhar.
     */
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("Erro: Driver H2 não encontrado.");
            throw new SQLException("Driver JDBC H2 indisponível.", e);
        }
     
        return DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
    }

    // ***************************************************************
    // 2. INICIALIZAÇÃO DO BANCO DE DADOS (CRIAÇÃO DE TABELAS)
    // ***************************************************************
    /**
     * Inicializa o esquema do banco de dados, criando todas as tabelas
     * necessárias se elas ainda não existirem.
     */
    public static void initializeDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            // 1. TIPO_PROBLEMA (Antigo TIPO_RISCO)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS TIPO_PROBLEMA ("
                    + "ID INT PRIMARY KEY AUTO_INCREMENT,"
                    + "NOME VARCHAR(255) NOT NULL,"
                    + "DESCRICAO VARCHAR(500)"
                    + ");");

            // 2. PROBLEMA (Antigo RISCO)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS PROBLEMA ("
                    + "ID INT PRIMARY KEY AUTO_INCREMENT,"
                    + "DESCRICAO VARCHAR(1000) NOT NULL,"
                    + "ORIGEM VARCHAR(255),"
                    + "DATA_IDENTIFICACAO DATE NOT NULL,"
                    + "STATUS VARCHAR(255),"
                    + "TIPO_PROBLEMA_ID INT," // Chave estrangeira renomeada
                    + "CONSTRAINT FK_PROBLEMA_TIPO FOREIGN KEY (TIPO_PROBLEMA_ID) REFERENCES TIPO_PROBLEMA(ID)"
                    + ");");

            // 3. CAUSA_RAIZ (Antigo AVALIACAO)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS CAUSA_RAIZ ("
                    + "ID INT PRIMARY KEY AUTO_INCREMENT,"
                    + "PROBLEMA_ID INT NOT NULL," // Chave estrangeira renomeada
                    + "IMPACTO INT," 
                    + "PROBABILIDADE INT," 
                    + "URGENCIA INT," 
                    + "PONTUACAO_GERAL INT," 
                    + "DATA_INVESTIGACAO DATE," // Coluna renomeada
                    + "RESPONSAVEL VARCHAR(255),"
                    + "JUSTIFICATIVA VARCHAR(1000),"
                    + "CONSTRAINT FK_CAUSARAIZ_PROBLEMA FOREIGN KEY (PROBLEMA_ID) REFERENCES PROBLEMA(ID),"
                    + "CONSTRAINT UN_CAUSARAIZ_PROBLEMA UNIQUE (PROBLEMA_ID)"
                    + ");");

            // 4. ACAO_CORRETIVA (Antigo PLANO_MITIGACAO)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS ACAO_CORRETIVA ("
                    + "ID INT PRIMARY KEY AUTO_INCREMENT,"
                    + "PROBLEMA_ID INT NOT NULL," // Chave estrangeira renomeada
                    + "DESCRICAO VARCHAR(1000) NOT NULL,"
                    + "DATA_PROPOSTA DATE,"
                    + "STATUS VARCHAR(255),"
                    + "CONSTRAINT FK_ACAO_PROBLEMA FOREIGN KEY (PROBLEMA_ID) REFERENCES PROBLEMA(ID)"
                    + ");");
            
            // 5. SUBACOES_CORRETIVAS (Antigo ACAO_MITIGACAO)
            stmt.executeUpdate("CREATE TABLE IF NOT EXISTS SUBACOES_CORRETIVAS ("
                    + "ID INT PRIMARY KEY AUTO_INCREMENT,"
                    + "ACAO_CORRETIVA_ID INT NOT NULL," // Chave estrangeira renomeada
                    + "DESCRICAO VARCHAR(500) NOT NULL,"
                    + "RESPONSAVEL VARCHAR(255) NOT NULL,"
                    + "PRAZO_CONCLUSAO DATE,"
                    + "DATA_CONCLUSAO DATE,"
                    + "PROGRESSO VARCHAR(255),"
                    + "OBSERVACOES VARCHAR(500),"
                    + "CONSTRAINT FK_SUBACOES_ACAO FOREIGN KEY (ACAO_CORRETIVA_ID) REFERENCES ACAO_CORRETIVA(ID)"
                    + ");");

            // 3. SEEDING (POVOAMENTO INICIAL)
            
            String checkSql = "SELECT COUNT(*) FROM TIPO_PROBLEMA";
            try (ResultSet rs = stmt.executeQuery(checkSql)) {
                if (rs.next() && rs.getInt(1) == 0) {
                    // Texto adaptado para o domínio de problemas
                    String insertSql = "INSERT INTO TIPO_PROBLEMA (NOME, DESCRICAO) VALUES ('Problema de Infraestrutura', 'Problemas relacionados a falhas de hardware ou rede.')";
                    stmt.executeUpdate(insertSql);
                    System.out.println("Tipo de problema padrão 'Problema de Infraestrutura' adicionado.");
                }
            }
            System.out.println("Banco de dados inicializado com sucesso para Gestão de Problemas.");
        } catch (SQLException e) {
            System.err.println("Erro ao inicializar o banco de dados: " + e.getMessage());
        }
    }
}